import React from 'react'
import ChatRoom from '../src/ChatRoom'

const App = () => {
  return (
    <ChatRoom />
  )
}

export default App;